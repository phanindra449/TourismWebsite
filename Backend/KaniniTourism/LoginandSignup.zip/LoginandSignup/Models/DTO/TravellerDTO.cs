﻿namespace LoginandSignup.Models.DTO
{
    public class TravellerDTO :Traveller
    { 
        public string? PasswordClear { get; set; }

    }
}
