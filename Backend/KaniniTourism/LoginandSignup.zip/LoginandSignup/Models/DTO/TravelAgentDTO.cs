﻿using LoginandSignup.Models;
namespace LoginandSignup.Models.DTO
{
    public class TravelAgentDTO :TravelAgent
    {

        public string? PasswordClear { get; set; }

    }
}
